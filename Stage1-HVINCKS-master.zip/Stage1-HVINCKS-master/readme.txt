------------------------------------README----------------------------------------
***1.INSTALL CORS EXTENSION(If accessed files from pc) from the link-- https://chrome.google.com/webstore/detail/allow-control-allow-origi/nlfbmbojpeacfghkpbjhddihlkkiljbi?hl=en
	PLEASE DISABLE ADD BLOCKER ON YOUR BROWSER
2.Use google chrome as preferred browser
3.Open home_page.html in your GOogle Chrome(CORS extension istalled and adblock disabled) to start!
4.Press "START SAVING" button on homepage and enter query in search box of "RESULTS"page to continue.
5.Price sorting options are available on the top.(Only High to low and Low to high)
6.At present the results are limited to FLIPKART AND EBAY only.
7.In any page if you want to return to home, you can press home button on header or logo which will redirect you to homepage.

IN CASE IF CODE DOSENT WORK PLEASE CALL +919494421244(SUSHANTH) OUR MAIN BACKEND DESIGNER or +919573544566(KRISHNA) FRONTEND DESIGNER and they will guide you through.
